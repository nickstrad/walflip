//#region .sdk-types/lib/c4/domain/model.d.ts
type Id = string;
type Status = 'existing' | 'planned' | 'mixed';
interface Diagnostic {
  readonly code: string;
  readonly path: string;
  readonly severity: 'error' | 'warning';
  readonly message: string;
}
interface References {
  readonly docIds: readonly Id[];
  readonly sourceIds: readonly Id[];
}
interface ElementBase extends References {
  readonly id: Id;
  readonly name: string;
  readonly description: string;
  readonly status: Status;
  readonly technology?: string;
  readonly tags: readonly string[];
  readonly plannedNotes: readonly string[];
}
type SymbolKind = 'class' | 'interface' | 'function' | 'type' | 'enum' | 'table' | 'module';
type Visibility = 'public' | 'protected' | 'private' | 'package';
/** Text-only declaration shown in a symbol compartment; never executed, parsed or fetched. */
interface CodeMember {
  readonly name: string;
  readonly signature?: string;
  readonly visibility: Visibility;
}
type RelationshipKind = 'dependency' | 'association' | 'inheritance' | 'implementation' | 'composition';
type Element = (ElementBase & {
  readonly kind: 'person' | 'softwareSystem';
}) | (ElementBase & {
  readonly kind: 'container';
  readonly parentId: Id;
  readonly technology: string;
  readonly containerType: 'application' | 'datastore';
}) | (ElementBase & {
  readonly kind: 'component';
  readonly parentId: Id;
  readonly technology: string;
}) | (ElementBase & {
  readonly kind: 'code';
  readonly parentId: Id;
  readonly symbolKind: SymbolKind;
  readonly members: readonly CodeMember[];
}) | (ElementBase & {
  readonly kind: 'deploymentNode';
  readonly environment: string;
  readonly technology: string;
  readonly parentId?: Id;
}) | (ElementBase & {
  readonly kind: 'infrastructureNode';
  readonly parentId: Id;
  readonly technology: string;
}) | (ElementBase & {
  readonly kind: 'instance';
  readonly instanceOf: Id;
  readonly parentId: Id;
  readonly environment: string;
});
interface Target {
  readonly diagramId: Id;
  readonly elementId?: Id;
}
interface Link extends Target {
  readonly label: string;
}
interface Relationship extends References {
  readonly id: Id;
  readonly sourceId: Id;
  readonly targetId: Id;
  readonly label: string;
  readonly modelRelationshipId?: Id;
  readonly status: Status;
  readonly technology?: string;
  readonly kind: RelationshipKind;
  readonly plannedNotes: readonly string[];
}
interface Member {
  readonly elementId: Id;
  readonly detail?: Target;
  readonly related: readonly Link[];
  readonly position?: {
    readonly x: number;
    readonly y: number;
  };
  readonly size?: {
    readonly width: number;
    readonly height: number;
  };
}
interface Group {
  readonly id: Id;
  readonly label: string;
  readonly memberIds: readonly Id[];
  readonly status: Status;
  readonly parentGroupId?: Id;
}
interface EdgeRef {
  readonly relationshipId: Id;
  readonly displayNumber?: number;
}
interface Swatch {
  readonly shape?: 'person' | 'box' | 'database' | 'boundary' | 'line';
  readonly tone: 'default' | 'external' | 'accent' | 'muted';
  readonly stroke: 'solid' | 'dashed' | 'dotted';
  readonly arrow?: 'none' | 'forward';
}
interface LegendEntry {
  readonly id: Id;
  readonly label: string;
  readonly description: string;
  readonly swatch: Swatch;
}
interface LegendSpec {
  readonly title: string;
  readonly entries: readonly LegendEntry[];
}
interface DiagramBase extends References {
  readonly id: Id;
  readonly parent?: Target;
  readonly related: readonly Link[];
  readonly title: string;
  readonly status: Status;
  readonly groups?: readonly Group[];
  readonly scopeId: Id;
  readonly nodes: readonly Member[];
  readonly edges: readonly EdgeRef[];
  readonly legend: LegendSpec;
  readonly layout?: {
    readonly mode: 'manual' | 'auto';
    readonly direction: 'TB' | 'LR';
    readonly spacing?: number;
  };
}
interface LandscapeDiagram extends Omit<DiagramBase, 'scopeId'> {
  readonly kind: 'landscape';
  readonly scopeId?: Id;
}
interface ContextDiagram extends DiagramBase {
  readonly kind: 'context';
}
interface ContainerDiagram extends DiagramBase {
  readonly kind: 'container';
}
interface ComponentDiagram extends DiagramBase {
  readonly kind: 'component';
}
interface CodeDiagram extends DiagramBase {
  readonly kind: 'code';
}
interface InteractionStep {
  readonly kind: 'interaction';
  readonly id: Id;
  readonly relationshipId: Id;
  readonly direction: 'forward' | 'reverse';
  readonly label: string;
}
type Step = InteractionStep | {
  readonly kind: 'sequence';
  readonly id: Id;
  readonly children: readonly Step[];
} | {
  readonly kind: 'parallel';
  readonly id: Id;
  readonly branches: readonly Step[];
};
interface DynamicDiagram extends Omit<DiagramBase, 'scopeId'> {
  readonly kind: 'dynamic';
  readonly scopeId?: Id;
  readonly scenario: Step;
}
interface DeploymentDiagram extends Omit<DiagramBase, 'scopeId'> {
  readonly kind: 'deployment';
  readonly scopeId?: Id;
  readonly environment: string;
}
type Diagram = LandscapeDiagram | ContextDiagram | ContainerDiagram | ComponentDiagram | CodeDiagram | DynamicDiagram | DeploymentDiagram;
interface Document {
  readonly sourceIds: readonly Id[];
  readonly id: Id;
  readonly title: string;
  readonly plain: string;
  readonly ste: {
    readonly text: string;
    readonly issue: string;
    readonly reviewStatus: 'draft' | 'reviewed';
    readonly reviewer?: string;
    readonly reviewedAt?: string;
  };
  readonly termIds: readonly Id[];
}
interface Source {
  readonly id: Id;
  readonly title: string;
  readonly url: string;
  readonly revision?: string;
  readonly path?: string;
  readonly notes?: string;
}
interface Term {
  readonly id: Id;
  readonly text: string;
  readonly definition: string;
  readonly category: 'technicalNoun' | 'technicalVerb';
}
interface ArchitectureBundle {
  readonly schemaVersion: 1;
  readonly id: Id;
  readonly title: string;
  readonly revision: string;
  readonly defaultDiagramId: Id;
  readonly model: {
    readonly elements: readonly Element[];
    readonly relationships: readonly Relationship[];
  };
  readonly diagrams: readonly Diagram[];
  readonly documents: readonly Document[];
  readonly sources: readonly Source[];
  readonly terms: readonly Term[];
}
interface ModelIndex {
  readonly bundle: ArchitectureBundle;
  readonly elements: Readonly<Record<Id, Element>>;
  readonly relationships: Readonly<Record<Id, Relationship>>;
  readonly diagrams: Readonly<Record<Id, Diagram>>;
  readonly documents: Readonly<Record<Id, Document>>;
  readonly sources: Readonly<Record<Id, Source>>;
  readonly terms: Readonly<Record<Id, Term>>;
}
type Result<T> = {
  readonly ok: true;
  readonly value: T;
  readonly diagnostics: readonly Diagnostic[];
} | {
  readonly ok: false;
  readonly diagnostics: readonly Diagnostic[];
};
interface ValidatedArchitecture {
  readonly bundle: ArchitectureBundle;
  readonly index: ModelIndex;
  readonly diagnostics: readonly Diagnostic[];
}
//#endregion
//#region .sdk-types/lib/c4/schema/decode.d.ts
interface DecodeLimits {
  readonly maxElements?: number;
  readonly maxRelationships?: number;
  readonly maxDiagrams?: number;
  readonly maxJsonDepth?: number;
  readonly maxScenarioJsonDepth?: number;
}
export declare function decodeArchitecture(input: unknown, limits?: DecodeLimits): Result<ValidatedArchitecture>;
//#endregion
//#region .sdk-types/core/public/editor-schema.d.ts
/** Editor shape only. Runtime decoding remains the validation boundary. */
export declare const architectureJsonSchema: Readonly<Record<string, unknown>>;
//#endregion
//#region .sdk-types/lib/c4/domain/geometry.d.ts
/** All geometry is absolute in the scene coordinate space, including nested children. */
interface Point {
  readonly x: number;
  readonly y: number;
}
interface Size {
  readonly width: number;
  readonly height: number;
}
interface Bounds extends Point, Size {}
interface EdgeSection {
  readonly startPoint: Point;
  readonly endPoint: Point;
  readonly bendPoints?: readonly Point[];
}
interface SceneNode extends Bounds {
  readonly element: Element;
  readonly parentGroupId?: Id;
  readonly labelBounds?: Bounds;
  readonly tone: 'accent' | 'external' | 'default';
  readonly stroke: 'solid' | 'dashed';
  readonly kindLabel: string;
  readonly statusText: string;
}
interface SceneGroup extends Bounds {
  readonly group: Group;
  readonly parentGroupId?: Id;
  readonly labelBounds?: Bounds;
}
interface SceneEdge {
  readonly relationship: Relationship;
  readonly source: SceneNode;
  readonly target: SceneNode;
  readonly number?: number;
  readonly stroke: 'solid' | 'dashed';
  readonly x1: number;
  readonly y1: number;
  readonly x2: number;
  readonly y2: number;
  readonly labelX: number;
  readonly labelY: number;
  readonly sections?: readonly EdgeSection[];
  readonly labelBounds?: Bounds;
}
interface Scene {
  readonly architectureId?: string;
  readonly revision?: string;
  readonly diagram: Diagram;
  readonly nodes: readonly SceneNode[];
  readonly edges: readonly SceneEdge[];
  readonly groups?: readonly SceneGroup[];
  readonly width: number;
  readonly height: number;
  readonly statusText: string;
  readonly kindLabel?: string;
}
//#endregion
//#region .sdk-types/lib/c4/domain/scene.d.ts
interface SceneInput {
  readonly architectureId: string;
  readonly revision: string;
  readonly diagram: Diagram;
  readonly kindLabel: string;
  readonly statusText: string;
  readonly groups: readonly Group[];
  readonly nodes: readonly {
    readonly element: Element;
    readonly kindLabel: string;
    readonly parentGroupId?: string;
    readonly tone: 'accent' | 'external' | 'default';
    readonly stroke: 'solid' | 'dashed';
    readonly statusText: string;
  }[];
  readonly edges: readonly {
    readonly relationship: Relationship;
    readonly number?: number;
    readonly stroke: 'solid' | 'dashed';
  }[];
}
export declare function buildScene(index: ModelIndex, diagramId: string): Result<SceneInput>;
//#endregion
//#region .sdk-types/lib/c4/domain/documentation.d.ts
interface DocumentSelection {
  readonly itemSourceIds?: readonly string[];
  readonly title: string;
  readonly description?: string;
  readonly statusText?: string;
  readonly plannedNotes: readonly string[];
  readonly documents: readonly Document[];
  readonly sources: readonly Source[];
  readonly terms: readonly Term[];
}
export declare function selectDocumentation(index: ModelIndex, diagramId: string, elementId?: string): DocumentSelection;
export declare function resolveLegend(index: ModelIndex, diagramId: string): LegendSpec | undefined;
//#endregion
//#region .sdk-types/lib/c4/domain/navigation.d.ts
interface Route extends Target {
  readonly architectureId: string;
  readonly stepId?: string;
}
export declare function formatRoute(route: Route): string;
export declare function parseRoute(hash: string): Result<Route | undefined>;
export declare function validateRoute(index: ModelIndex, route: Route): readonly Diagnostic[];
export declare function breadcrumbs(index: ModelIndex, route: Route): readonly Target[];
type NavigationAction = {
  readonly type: 'step';
  readonly stepId?: string;
} | {
  readonly type: 'activate' | 'inspect';
  readonly elementId: string;
} | {
  readonly type: 'diagram' | 'up' | 'back';
} | {
  readonly type: 'target';
  readonly target: Target;
};
type NavigationEffect = {
  readonly type: 'push';
  readonly route: Route;
} | {
  readonly type: 'back';
};
/** Pure decisions only: browser history owns Back; no duplicate navigation stack. */
export declare function transition(index: ModelIndex, route: Route, action: NavigationAction, canGoBack?: boolean): Result<NavigationEffect>;
//#endregion
//#region .sdk-types/lib/c4/ports/route.d.ts
interface RouteSnapshot {
  readonly hash: string;
  readonly canGoBack: boolean;
}
interface RoutePort {
  readonly getSnapshot: () => RouteSnapshot;
  readonly subscribe: (listener: () => void) => () => void;
  readonly push: (route: Route) => void;
  readonly replace: (route: Route) => void;
  readonly back: () => void;
}
//#endregion
//#region .sdk-types/lib/c4/ports/layout.d.ts
interface LayoutMeasurements {
  readonly revision: string;
  readonly nodeSizes: Readonly<Partial<Record<string, Size>>>;
  readonly edgeLabelSizes: Readonly<Partial<Record<string, Size>>>;
  readonly groupLabelSizes?: Readonly<Partial<Record<string, Size>>>;
}
interface LayoutRequest {
  readonly scene: SceneInput;
  readonly generation: number;
  readonly signal: AbortSignal;
  readonly measurements?: LayoutMeasurements;
  readonly timeoutMs?: number;
}
interface LayoutResponse {
  readonly generation: number;
  readonly result: Result<Scene>;
  readonly measurementRevision?: string;
}
/** Return absolute finite geometry or diagnostics. Never publish aborted/stale generations. */
interface LayoutPort {
  readonly layout: (request: LayoutRequest) => Promise<LayoutResponse>;
}
//#endregion
//#region .sdk-types/lib/c4/domain/layout.d.ts
interface GeometryLimits {
  readonly maxCoordinate?: number;
  readonly maxExtent?: number;
}
//#endregion
//#region .sdk-types/lib/c4/ports/loader.d.ts
interface CatalogEntry {
  readonly id: string;
  readonly title: string;
  readonly url: string;
}
interface Catalog {
  readonly entries: readonly CatalogEntry[];
}
interface ArchitectureLoader {
  loadCatalog(url: string, signal: AbortSignal): Promise<Catalog>;
  loadBundle(url: string, signal: AbortSignal): Promise<Result<ValidatedArchitecture>>;
}
//#endregion
export type { ArchitectureBundle, ArchitectureLoader, Bounds, Catalog, CatalogEntry, CodeDiagram, CodeMember, ComponentDiagram, ContainerDiagram, ContextDiagram, DecodeLimits, DeploymentDiagram, Diagnostic, Diagram, Document, DocumentSelection, DynamicDiagram, EdgeRef, EdgeSection, Element, GeometryLimits, Group, Id, InteractionStep, LandscapeDiagram, LayoutMeasurements, LayoutPort, LayoutRequest, LayoutResponse, LegendEntry, LegendSpec, Link, Member, ModelIndex, NavigationAction, NavigationEffect, Point, References, Relationship, RelationshipKind, Result, Route, RoutePort, RouteSnapshot, Scene, SceneEdge, SceneGroup, SceneInput, SceneNode, Size, Source, Status, Step, Swatch, SymbolKind, Target, Term, ValidatedArchitecture, Visibility };
import implementation from './core.cjs'
export const architectureJsonSchema = implementation.architectureJsonSchema
export const breadcrumbs = implementation.breadcrumbs
export const buildScene = implementation.buildScene
export const decodeArchitecture = implementation.decodeArchitecture
export const formatRoute = implementation.formatRoute
export const parseRoute = implementation.parseRoute
export const resolveLegend = implementation.resolveLegend
export const selectDocumentation = implementation.selectDocumentation
export const transition = implementation.transition
export const validateRoute = implementation.validateRoute

import { FocusEvent, MouseEvent as MouseEvent$1, MouseEventHandler, ReactNode } from "react";
//#region .sdk-types/lib/c4/domain/model.d.ts
type Id = string;
type Status = 'existing' | 'planned' | 'mixed';
interface Diagnostic {
  readonly code: string;
  readonly path: string;
  readonly severity: 'error' | 'warning';
  readonly message: string;
}
interface References {
  readonly docIds: readonly Id[];
  readonly sourceIds: readonly Id[];
}
interface ElementBase extends References {
  readonly id: Id;
  readonly name: string;
  readonly description: string;
  readonly status: Status;
  readonly technology?: string;
  readonly tags: readonly string[];
  readonly plannedNotes: readonly string[];
}
type SymbolKind = 'class' | 'interface' | 'function' | 'type' | 'enum' | 'table' | 'module';
type Visibility = 'public' | 'protected' | 'private' | 'package';
/** Text-only declaration shown in a symbol compartment; never executed, parsed or fetched. */
interface CodeMember {
  readonly name: string;
  readonly signature?: string;
  readonly visibility: Visibility;
}
type RelationshipKind = 'dependency' | 'association' | 'inheritance' | 'implementation' | 'composition';
type Element$1 = (ElementBase & {
  readonly kind: 'person' | 'softwareSystem';
}) | (ElementBase & {
  readonly kind: 'container';
  readonly parentId: Id;
  readonly technology: string;
  readonly containerType: 'application' | 'datastore';
}) | (ElementBase & {
  readonly kind: 'component';
  readonly parentId: Id;
  readonly technology: string;
}) | (ElementBase & {
  readonly kind: 'code';
  readonly parentId: Id;
  readonly symbolKind: SymbolKind;
  readonly members: readonly CodeMember[];
}) | (ElementBase & {
  readonly kind: 'deploymentNode';
  readonly environment: string;
  readonly technology: string;
  readonly parentId?: Id;
}) | (ElementBase & {
  readonly kind: 'infrastructureNode';
  readonly parentId: Id;
  readonly technology: string;
}) | (ElementBase & {
  readonly kind: 'instance';
  readonly instanceOf: Id;
  readonly parentId: Id;
  readonly environment: string;
});
interface Target {
  readonly diagramId: Id;
  readonly elementId?: Id;
}
interface Link extends Target {
  readonly label: string;
}
interface Relationship extends References {
  readonly id: Id;
  readonly sourceId: Id;
  readonly targetId: Id;
  readonly label: string;
  readonly modelRelationshipId?: Id;
  readonly status: Status;
  readonly technology?: string;
  readonly kind: RelationshipKind;
  readonly plannedNotes: readonly string[];
}
interface Member {
  readonly elementId: Id;
  readonly detail?: Target;
  readonly related: readonly Link[];
  readonly position?: {
    readonly x: number;
    readonly y: number;
  };
  readonly size?: {
    readonly width: number;
    readonly height: number;
  };
}
interface Group {
  readonly id: Id;
  readonly label: string;
  readonly memberIds: readonly Id[];
  readonly status: Status;
  readonly parentGroupId?: Id;
}
interface EdgeRef {
  readonly relationshipId: Id;
  readonly displayNumber?: number;
}
interface Swatch {
  readonly shape?: 'person' | 'box' | 'database' | 'boundary' | 'line';
  readonly tone: 'default' | 'external' | 'accent' | 'muted';
  readonly stroke: 'solid' | 'dashed' | 'dotted';
  readonly arrow?: 'none' | 'forward';
}
interface LegendEntry {
  readonly id: Id;
  readonly label: string;
  readonly description: string;
  readonly swatch: Swatch;
}
interface LegendSpec {
  readonly title: string;
  readonly entries: readonly LegendEntry[];
}
interface DiagramBase extends References {
  readonly id: Id;
  readonly parent?: Target;
  readonly related: readonly Link[];
  readonly title: string;
  readonly status: Status;
  readonly groups?: readonly Group[];
  readonly scopeId: Id;
  readonly nodes: readonly Member[];
  readonly edges: readonly EdgeRef[];
  readonly legend: LegendSpec;
  readonly layout?: {
    readonly mode: 'manual' | 'auto';
    readonly direction: 'TB' | 'LR';
    readonly spacing?: number;
  };
}
interface LandscapeDiagram extends Omit<DiagramBase, 'scopeId'> {
  readonly kind: 'landscape';
  readonly scopeId?: Id;
}
interface ContextDiagram extends DiagramBase {
  readonly kind: 'context';
}
interface ContainerDiagram$1 extends DiagramBase {
  readonly kind: 'container';
}
interface ComponentDiagram$1 extends DiagramBase {
  readonly kind: 'component';
}
interface CodeDiagram$1 extends DiagramBase {
  readonly kind: 'code';
}
interface InteractionStep {
  readonly kind: 'interaction';
  readonly id: Id;
  readonly relationshipId: Id;
  readonly direction: 'forward' | 'reverse';
  readonly label: string;
}
type Step = InteractionStep | {
  readonly kind: 'sequence';
  readonly id: Id;
  readonly children: readonly Step[];
} | {
  readonly kind: 'parallel';
  readonly id: Id;
  readonly branches: readonly Step[];
};
interface DynamicDiagram$1 extends Omit<DiagramBase, 'scopeId'> {
  readonly kind: 'dynamic';
  readonly scopeId?: Id;
  readonly scenario: Step;
}
interface DeploymentDiagram$1 extends Omit<DiagramBase, 'scopeId'> {
  readonly kind: 'deployment';
  readonly scopeId?: Id;
  readonly environment: string;
}
type Diagram = LandscapeDiagram | ContextDiagram | ContainerDiagram$1 | ComponentDiagram$1 | CodeDiagram$1 | DynamicDiagram$1 | DeploymentDiagram$1;
interface Document {
  readonly sourceIds: readonly Id[];
  readonly id: Id;
  readonly title: string;
  readonly plain: string;
  readonly ste: {
    readonly text: string;
    readonly issue: string;
    readonly reviewStatus: 'draft' | 'reviewed';
    readonly reviewer?: string;
    readonly reviewedAt?: string;
  };
  readonly termIds: readonly Id[];
}
interface Source {
  readonly id: Id;
  readonly title: string;
  readonly url: string;
  readonly revision?: string;
  readonly path?: string;
  readonly notes?: string;
}
interface Term {
  readonly id: Id;
  readonly text: string;
  readonly definition: string;
  readonly category: 'technicalNoun' | 'technicalVerb';
}
interface ArchitectureBundle {
  readonly schemaVersion: 1;
  readonly id: Id;
  readonly title: string;
  readonly revision: string;
  readonly defaultDiagramId: Id;
  readonly model: {
    readonly elements: readonly Element$1[];
    readonly relationships: readonly Relationship[];
  };
  readonly diagrams: readonly Diagram[];
  readonly documents: readonly Document[];
  readonly sources: readonly Source[];
  readonly terms: readonly Term[];
}
interface ModelIndex {
  readonly bundle: ArchitectureBundle;
  readonly elements: Readonly<Record<Id, Element$1>>;
  readonly relationships: Readonly<Record<Id, Relationship>>;
  readonly diagrams: Readonly<Record<Id, Diagram>>;
  readonly documents: Readonly<Record<Id, Document>>;
  readonly sources: Readonly<Record<Id, Source>>;
  readonly terms: Readonly<Record<Id, Term>>;
}
type Result<T> = {
  readonly ok: true;
  readonly value: T;
  readonly diagnostics: readonly Diagnostic[];
} | {
  readonly ok: false;
  readonly diagnostics: readonly Diagnostic[];
};
interface ValidatedArchitecture {
  readonly bundle: ArchitectureBundle;
  readonly index: ModelIndex;
  readonly diagnostics: readonly Diagnostic[];
}
//#endregion
//#region .sdk-types/lib/c4/domain/geometry.d.ts
/** All geometry is absolute in the scene coordinate space, including nested children. */
interface Point {
  readonly x: number;
  readonly y: number;
}
interface Size {
  readonly width: number;
  readonly height: number;
}
interface Bounds extends Point, Size {}
interface EdgeSection {
  readonly startPoint: Point;
  readonly endPoint: Point;
  readonly bendPoints?: readonly Point[];
}
interface SceneNode extends Bounds {
  readonly element: Element$1;
  readonly parentGroupId?: Id;
  readonly labelBounds?: Bounds;
  readonly tone: 'accent' | 'external' | 'default';
  readonly stroke: 'solid' | 'dashed';
  readonly kindLabel: string;
  readonly statusText: string;
}
interface SceneGroup extends Bounds {
  readonly group: Group;
  readonly parentGroupId?: Id;
  readonly labelBounds?: Bounds;
}
interface SceneEdge {
  readonly relationship: Relationship;
  readonly source: SceneNode;
  readonly target: SceneNode;
  readonly number?: number;
  readonly stroke: 'solid' | 'dashed';
  readonly x1: number;
  readonly y1: number;
  readonly x2: number;
  readonly y2: number;
  readonly labelX: number;
  readonly labelY: number;
  readonly sections?: readonly EdgeSection[];
  readonly labelBounds?: Bounds;
}
interface Scene {
  readonly architectureId?: string;
  readonly revision?: string;
  readonly diagram: Diagram;
  readonly nodes: readonly SceneNode[];
  readonly edges: readonly SceneEdge[];
  readonly groups?: readonly SceneGroup[];
  readonly width: number;
  readonly height: number;
  readonly statusText: string;
  readonly kindLabel?: string;
}
//#endregion
//#region .sdk-types/lib/c4/domain/scene.d.ts
interface SceneInput {
  readonly architectureId: string;
  readonly revision: string;
  readonly diagram: Diagram;
  readonly kindLabel: string;
  readonly statusText: string;
  readonly groups: readonly Group[];
  readonly nodes: readonly {
    readonly element: Element$1;
    readonly kindLabel: string;
    readonly parentGroupId?: string;
    readonly tone: 'accent' | 'external' | 'default';
    readonly stroke: 'solid' | 'dashed';
    readonly statusText: string;
  }[];
  readonly edges: readonly {
    readonly relationship: Relationship;
    readonly number?: number;
    readonly stroke: 'solid' | 'dashed';
  }[];
}
//#endregion
//#region .sdk-types/lib/c4/ports/layout.d.ts
interface LayoutMeasurements {
  readonly revision: string;
  readonly nodeSizes: Readonly<Partial<Record<string, Size>>>;
  readonly edgeLabelSizes: Readonly<Partial<Record<string, Size>>>;
  readonly groupLabelSizes?: Readonly<Partial<Record<string, Size>>>;
}
interface LayoutRequest {
  readonly scene: SceneInput;
  readonly generation: number;
  readonly signal: AbortSignal;
  readonly measurements?: LayoutMeasurements;
  readonly timeoutMs?: number;
}
interface LayoutResponse {
  readonly generation: number;
  readonly result: Result<Scene>;
  readonly measurementRevision?: string;
}
/** Return absolute finite geometry or diagnostics. Never publish aborted/stale generations. */
interface LayoutPort {
  readonly layout: (request: LayoutRequest) => Promise<LayoutResponse>;
}
//#endregion
//#region .sdk-types/lib/c4/domain/navigation.d.ts
interface Route extends Target {
  readonly architectureId: string;
  readonly stepId?: string;
}
type NavigationAction = {
  readonly type: 'step';
  readonly stepId?: string;
} | {
  readonly type: 'activate' | 'inspect';
  readonly elementId: string;
} | {
  readonly type: 'diagram' | 'up' | 'back';
} | {
  readonly type: 'target';
  readonly target: Target;
};
//#endregion
//#region .sdk-types/lib/c4/ports/route.d.ts
interface RouteSnapshot {
  readonly hash: string;
  readonly canGoBack: boolean;
}
interface RoutePort {
  readonly getSnapshot: () => RouteSnapshot;
  readonly subscribe: (listener: () => void) => () => void;
  readonly push: (route: Route) => void;
  readonly replace: (route: Route) => void;
  readonly back: () => void;
}
//#endregion
//#region .sdk-types/lib/c4/domain/scenario.d.ts
interface ScenarioItem {
  readonly id: string;
  readonly label: string;
  readonly kind: Step['kind'];
  readonly number: string;
  readonly children: readonly ScenarioItem[];
  readonly interaction?: InteractionStep;
}
interface InteractionOverlay {
  readonly id: string;
  readonly relationshipId: string;
  readonly number: string;
  readonly label: string;
  readonly direction: 'forward' | 'reverse';
  readonly sourceName: string;
  readonly targetName: string;
}
//#endregion
//#region .sdk-types/lib/c4/react/views/NavigationView.d.ts
interface NavigationViewProps {
  readonly breadcrumbs: readonly (DestinationLinkProps & {
    readonly id: string;
    readonly title: string;
    readonly current: boolean;
  })[];
  readonly onBack: () => void;
  readonly up?: DestinationLinkProps;
  readonly related: readonly (DestinationLinkProps & {
    readonly label: string;
  })[];
}
//#endregion
//#region .sdk-types/lib/c4/domain/documentation.d.ts
interface DocumentSelection {
  readonly itemSourceIds?: readonly string[];
  readonly title: string;
  readonly description?: string;
  readonly statusText?: string;
  readonly plannedNotes: readonly string[];
  readonly documents: readonly Document[];
  readonly sources: readonly Source[];
  readonly terms: readonly Term[];
}
//#endregion
//#region .sdk-types/lib/c4/react/contracts/views.d.ts
interface DestinationLinkProps {
  readonly href: string;
  readonly onClick: MouseEventHandler<HTMLAnchorElement>;
}
type NavigationSlot = (props: NavigationViewProps) => ReactNode;
type LegendSlot = (props: LegendProps) => ReactNode;
type DocumentationSlot = (props: DocumentationViewProps) => ReactNode;
interface DocumentationViewProps {
  readonly selection: DocumentSelection;
  readonly mode: 'plain' | 'ste';
  readonly onPlain: () => void;
  readonly onSte: () => void;
  readonly document?: Document;
  readonly documentId?: string;
  readonly onDocument?: (id: string) => void;
}
interface LegendProps extends LegendSpec {
  readonly compact?: boolean;
}
//#endregion
//#region .sdk-types/lib/c4/react/containers/ArchitectureViewer.d.ts
interface ArchitectureViewerProps {
  readonly validatedBundle: ValidatedArchitecture;
  readonly diagramId?: string;
  readonly routePort?: RoutePort;
  readonly layoutPort?: LayoutPort;
  /** Reject any routed diagram of another kind. Named wrappers set this; the check follows the actual route. */
  readonly expectedKind?: Diagram['kind'];
  readonly navigationSlot?: NavigationSlot;
  readonly legendSlot?: LegendSlot;
  readonly documentationSlot?: DocumentationSlot;
}
/** Wrappers hide `expectedKind`; they cannot be configured for another kind. */
type NamedDiagramProps = Omit<ArchitectureViewerProps, 'expectedKind'>;
interface ArchitectureProviderProps extends Pick<ArchitectureViewerProps, 'validatedBundle' | 'diagramId' | 'routePort' | 'layoutPort' | 'expectedKind'> {
  readonly children?: ReactNode;
}
/**
 * One route/navigation/session controller for every composed part below it. Parts read it through
 * context, so a custom layout can never create a second controller for the same viewer.
 */
export declare function ArchitectureProvider({ validatedBundle, diagramId, routePort, layoutPort, expectedKind, children }: ArchitectureProviderProps): import("react").JSX.Element;
export declare function DiagramNavigation({ slot }: {
  slot?: NavigationSlot;
}): import("react").JSX.Element;
export declare function DiagramView({ legendSlot }: {
  legendSlot?: LegendSlot;
}): import("react").JSX.Element;
/** The key for the routed diagram, for layouts that place it away from the canvas (pair with `legendSlot={() => null}`). */
export declare function DiagramLegend({ slot }: {
  slot?: LegendSlot;
}): import("react").JSX.Element | null;
export declare function DiagramDocumentation({ slot }: {
  slot?: DocumentationSlot;
}): import("react").JSX.Element | null;
export declare function ArchitectureViewer({ navigationSlot, legendSlot, documentationSlot, ...provider }: ArchitectureViewerProps): import("react").JSX.Element;
//#endregion
//#region .sdk-types/lib/c4/react/containers/NamedDiagrams.d.ts
export declare function SystemLandscape(props: NamedDiagramProps): import("react").JSX.Element;
export declare function SystemContext(props: NamedDiagramProps): import("react").JSX.Element;
export declare function ContainerDiagram(props: NamedDiagramProps): import("react").JSX.Element;
export declare function ComponentDiagram(props: NamedDiagramProps): import("react").JSX.Element;
export declare function CodeDiagram(props: NamedDiagramProps): import("react").JSX.Element;
export declare function DynamicDiagram(props: NamedDiagramProps): import("react").JSX.Element;
export declare function DeploymentDiagram(props: NamedDiagramProps): import("react").JSX.Element;
//#endregion
//#region .sdk-types/lib/c4/ports/loader.d.ts
interface CatalogEntry {
  readonly id: string;
  readonly title: string;
  readonly url: string;
}
interface Catalog {
  readonly entries: readonly CatalogEntry[];
}
interface ArchitectureLoader {
  loadCatalog(url: string, signal: AbortSignal): Promise<Catalog>;
  loadBundle(url: string, signal: AbortSignal): Promise<Result<ValidatedArchitecture>>;
}
//#endregion
//#region .sdk-types/lib/c4/react/containers/CatalogViewer.d.ts
interface CatalogViewerProps {
  readonly catalogUrl: string;
  readonly loader?: ArchitectureLoader;
  readonly title?: string;
  readonly routePort?: RoutePort;
}
export declare function CatalogViewer({ catalogUrl, loader, title, routePort }: CatalogViewerProps): import("react").JSX.Element;
//#endregion
//#region .sdk-types/lib/c4/react/views/Legend.d.ts
export declare function Legend({ title, entries, compact }: LegendProps): import("react").JSX.Element;
//#endregion
//#region .sdk-types/lib/c4/react/hooks/useContext.d.ts
declare function useContext(architecture: ValidatedArchitecture, route: Route, navigate: (action: NavigationAction) => void, detail: (elementId: string) => DestinationLinkProps | undefined): {
  input: Result<SceneInput>;
  markerId: string;
  documentationProps: {
    selection: DocumentSelection;
    document: Document | undefined;
    documentId: string | undefined;
    mode: "plain" | "ste";
    onDocument: (id: string) => void;
    onPlain: () => void;
    onSte: () => void;
  };
  dynamic: {
    tree: ScenarioItem;
    selectedId: string | undefined;
    selected: ScenarioItem | undefined;
    overlays: readonly InteractionOverlay[];
    selections: readonly ScenarioItem[];
    onSelect: (stepId: string | undefined) => void;
    onPrevious: () => void;
    onNext: () => void;
    previousDisabled: boolean;
    nextDisabled: boolean;
  } | undefined;
  deployment: {
    projection: DeploymentDiagram$1;
    environment: string;
    hiddenCount: number;
    relationships: {
      id: string;
      source: string;
      target: string;
      label: string;
      status: Status;
    }[];
    rows: {
      id: string;
      name: string;
      description: string;
      status: Status;
      depth: number;
      parent: string | undefined;
      logical: string | undefined;
      kind: "person" | "softwareSystem" | "container" | "component" | "code" | "deploymentNode" | "infrastructureNode" | "instance";
      selected: boolean;
      collapsed: boolean;
      onToggle: () => void;
      onInspect: () => void;
      detail: DestinationLinkProps | undefined;
    }[];
  } | undefined;
  canvasActions: {
    onDiagramSelect: () => void;
    nodeActions: (elementId: string) => {
      selected: boolean;
      detail: DestinationLinkProps | undefined;
      onSelect: () => void;
      onInspect: () => void;
    };
  };
};
//#endregion
//#region .sdk-types/lib/c4/react/hooks/useNavigation.d.ts
declare function useNavigation(architecture: ValidatedArchitecture, port: RoutePort, initialDiagramId?: string): {
  route: Route;
  diagnostics: readonly Diagnostic[];
  navigate: (action: NavigationAction) => void;
  diagramTitle: string;
  recovery: {
    href: string;
    onClick: (event: MouseEvent$1<HTMLAnchorElement>) => void;
  };
  detail: (elementId: string) => {
    href: string;
    onClick: (event: MouseEvent$1<HTMLAnchorElement>) => void;
  } | undefined;
  viewProps: {
    breadcrumbs: {
      href: string;
      onClick: (event: MouseEvent$1<HTMLAnchorElement>) => void;
      id: string;
      title: string;
      current: boolean;
    }[];
    onBack: () => void;
    up: {
      href: string;
      onClick: (event: MouseEvent$1<HTMLAnchorElement>) => void;
    } | undefined;
    related: {
      href: string;
      onClick: (event: MouseEvent$1<HTMLAnchorElement>) => void;
      label: string;
    }[];
  };
};
//#endregion
//#region node_modules/@xyflow/system/dist/esm/types/general.d.ts
/**
 * Internally, React Flow maintains a coordinate system that is independent of the
 * rest of the page. The `Viewport` type tells you where in that system your flow
 * is currently being display at and how zoomed in or out it is.
 *
 * @public
 * @remarks A `Transform` has the same properties as the viewport, but they represent
 * different things. Make sure you don't get them muddled up or things will start
 * to look weird!
 *
 */
type Viewport = {
  x: number;
  y: number;
  zoom: number;
};
//#endregion
//#region .sdk-types/lib/c4/react/hooks/useViewerSession.d.ts
declare function useViewerSession(route: Route, revision: string): {
  rootProps: {
    ref: import("react").RefObject<HTMLDivElement | null>;
    'data-c4-viewer-host': boolean;
    onFocusCapture: (event: FocusEvent<HTMLDivElement>) => void;
  };
  canvasSession: {
    getFocusedElement: () => HTMLElement | undefined;
    getViewport: () => Viewport | undefined;
    onViewport: (viewport: Viewport) => void;
    onReady: () => void;
  };
};
//#endregion
//#region .sdk-types/lib/c4/react/hooks/useViewerController.d.ts
interface ViewerController {
  readonly architecture: ValidatedArchitecture;
  readonly navigation: ReturnType<typeof useNavigation>;
  readonly context: ReturnType<typeof useContext>;
  readonly session: ReturnType<typeof useViewerSession>;
  readonly layoutPort?: LayoutPort;
  readonly expectedKind?: Diagram['kind'];
}
/** Read-only view of the shared controller for custom parts. It cannot start a second route. */
export declare function useViewerController(): {
  readonly route: ViewerController['navigation']['route'];
  readonly diagram: Diagram | undefined;
  readonly validatedBundle: ValidatedArchitecture;
  readonly navigate: ViewerController['navigation']['navigate'];
};
//#endregion
//#region .sdk-types/lib/c4/schema/decode.d.ts
interface DecodeLimits {
  readonly maxElements?: number;
  readonly maxRelationships?: number;
  readonly maxDiagrams?: number;
  readonly maxJsonDepth?: number;
  readonly maxScenarioJsonDepth?: number;
}
//#endregion
//#region .sdk-types/lib/c4/adapters/loaders/fetch.d.ts
interface FetchLoaderLimits {
  readonly maxBundleBytes?: number;
  readonly maxCatalogBytes?: number;
  readonly decode?: DecodeLimits;
}
export declare function createFetchLoader(fetchResource?: typeof fetch, limits?: FetchLoaderLimits): ArchitectureLoader;
//#endregion
//#region .sdk-types/lib/c4/adapters/router/hash.d.ts
/** Tracks only same-session viewer entry depth in browser state, never a second route stack. */
export declare function createHashRoutePort(browser?: Window): RoutePort;
//#endregion
//#region .sdk-types/lib/c4/domain/layout.d.ts
interface GeometryLimits {
  readonly maxCoordinate?: number;
  readonly maxExtent?: number;
}
//#endregion
//#region .sdk-types/lib/c4/adapters/layout/client.d.ts
interface LayoutWorker {
  postMessage(message: unknown): void;
  terminate(): void;
  onmessage: ((event: MessageEvent) => void) | null;
  onerror: ((event: ErrorEvent) => void) | null;
  onmessageerror: ((event: MessageEvent) => void) | null;
}
interface ElkLayoutLimits {
  readonly geometry?: GeometryLimits;
  readonly maxNodes?: number;
  readonly maxEdges?: number;
  readonly cacheEntries?: number;
  readonly timeoutMs?: number;
}
/** Cache geometry only; a hit still reattaches this caller's original model references. */
export declare function createElkLayoutPort(factory?: () => LayoutWorker, limits?: ElkLayoutLimits): LayoutPort;
//#endregion
export type { ArchitectureProviderProps, ArchitectureViewerProps, CatalogViewerProps, DestinationLinkProps, DocumentationSlot, DocumentationViewProps, ElkLayoutLimits, FetchLoaderLimits, LayoutWorker, LegendProps, LegendSlot, NamedDiagramProps, NavigationSlot, NavigationViewProps };
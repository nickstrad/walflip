Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_decode = require("./shared-Fjju4RBi.cjs");
//#region src/core/public/editor-schema.ts
/** Editor shape only. Runtime decoding remains the validation boundary. */
const architectureJsonSchema = require_decode.architectureJsonSchema;
//#endregion
exports.architectureJsonSchema = architectureJsonSchema;
exports.breadcrumbs = require_decode.breadcrumbs;
exports.buildScene = require_decode.buildScene;
exports.decodeArchitecture = require_decode.decodeArchitecture;
exports.formatRoute = require_decode.formatRoute;
exports.parseRoute = require_decode.parseRoute;
exports.resolveLegend = require_decode.resolveLegend;
exports.selectDocumentation = require_decode.selectDocumentation;
exports.transition = require_decode.transition;
exports.validateRoute = require_decode.validateRoute;
